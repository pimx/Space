# 6-DOF Rocket Dynamics Model

## Overview

This Modelica package implements a complete 6-degree-of-freedom (6-DOF) rocket dynamics simulation with the following features:

- **Integration Frame**: Earth-Centered Inertial (ECI) frame
- **Output Frame**: Earth-Centered Earth-Fixed (ECEF) frame with WGS84 geodetic coordinates
- **Body Frame Convention**: X-forward (nose), Y-right, Z-down
- **Thrust Control**: Direct magnitude and direction vector in body frame with first-order dynamics
- **Mass Properties**: Variable mass with fuel depletion, shifting center of mass, and changing inertia tensor
- **Aerodynamics**: Full 6-DOF forces and moments with placeholder coefficient functions
- **Gravity**: Simple point-mass Earth gravity model (μ/r²)

## Model Structure

### Main Components

1. **Rocket** - Main 6-DOF dynamics model
   - Integrates translational motion in ECI frame
   - Integrates rotational motion using quaternions
   - Outputs position/velocity in ECEF and Euler angles

2. **MassPropertiesModel** - Variable mass properties
   - Fuel depletion integration
   - Center of mass shift during burn
   - Inertia tensor updates with parallel axis theorem

3. **ThrustModel** - Thrust generation with dynamics
   - Magnitude control with first-order lag (τ = 0.1 s)
   - Direction control with first-order lag (τ = 0.05 s)
   - Thrust moments from offset application point
   - Specific impulse-based mass flow calculation

4. **AerodynamicsModel** - 6-DOF aerodynamic loads
   - Computes angle of attack (α) and sideslip (β)
   - Calculates Mach number
   - **PLACEHOLDER** aerodynamic coefficients (needs real data)
   - Outputs forces and moments in body frame

### Coordinate Frames

#### ECI (Earth-Centered Inertial)
- Origin: Earth's center
- Z-axis: Along Earth's rotation axis (North)
- X-axis: Points to vernal equinox
- Integration performed in this frame

#### ECEF (Earth-Centered Earth-Fixed)
- Origin: Earth's center
- Rotates with Earth at ω_earth = 7.2921159e-5 rad/s
- Output frame for position and velocity

#### Body Frame
- Origin: Rocket's center of mass
- X-axis: Forward (nose direction)
- Y-axis: Right
- Z-axis: Down (completes right-hand rule)
- Thrust and aerodynamic forces expressed in this frame

## State Variables

### Translational States (ECI Frame)
- `r_ECI[3]` - Position vector [m]
- `v_ECI[3]` - Velocity vector [m/s]

### Rotational States
- `q[4]` - Attitude quaternion [w, x, y, z] (ECI to Body transformation)
- `omega_body[3]` - Angular velocity in body frame [rad/s]

### Mass State
- `m_fuel` - Current fuel mass [kg]

### Thrust States (with dynamics)
- `T_actual` - Actual thrust magnitude [N]
- `u_thrust[3]` - Actual thrust direction unit vector

## Inputs

The rocket model has two main inputs:

1. **T_cmd** - Commanded thrust magnitude [N]
   - Range: 0 to T_max (default 100 kN)
   - First-order response with τ = 0.1 s

2. **u_thrust_cmd[3]** - Commanded thrust direction unit vector in body frame
   - Automatically normalized
   - First-order response with τ = 0.05 s
   - Example: `{1, 0, 0}` = pure axial thrust forward

## Outputs

### ECEF Frame Outputs
- `r_ECEF[3]` - Position in ECEF [m]
- `v_ECEF[3]` - Velocity in ECEF (accounts for Earth rotation) [m/s]

### Geodetic Coordinates (WGS84)
- `lat` - Latitude [rad]
- `lon` - Longitude [rad]
- `alt_geodetic` - Altitude above WGS84 ellipsoid [m]

### Attitude
- `euler_ECEF[3]` - Euler angles [yaw, pitch, roll] [rad]
  - Sequence: Z-Y-X (yaw-pitch-roll)
- `omega_body[3]` - Angular velocity in body frame [rad/s]

### Other Outputs
- `mass_model.m_total` - Current total mass [kg]
- `mass_model.x_cm` - Current center of mass position [m]
- `altitude` - Altitude above sea level [m]
- `q_dyn` - Dynamic pressure [Pa]

## Parameters to Customize

### Initial Conditions
```modelica
parameter Real r0_ECI[3] = {R_earth + 100e3, 0, 0};      // Position [m]
parameter Real v0_ECI[3] = {0, 7500, 0};                 // Velocity [m/s]
parameter Real q0[4] = {1, 0, 0, 0};                     // Quaternion
parameter Real omega0_body[3] = {0, 0, 0};               // Angular velocity [rad/s]
```

### Mass Properties (in MassPropertiesModel)
```modelica
parameter Real m_dry = 1000.0;                           // Dry mass [kg]
parameter Real m_fuel_initial = 9000.0;                  // Fuel mass [kg]
parameter Real x_cm_dry = 0.0;                           // Dry CoM from nose [m]
parameter Real x_fuel_empty = -5.0;                      // Empty tank CoM [m]
parameter Real x_fuel_full = -5.0;                       // Full tank CoM [m]
parameter Real I_dry[3,3] = [1000,0,0; 0,10000,0; 0,0,10000]; // Dry inertia [kg·m²]
parameter Real I_fuel_full[3,3] = [500,0,0; 0,5000,0; 0,0,5000]; // Fuel inertia [kg·m²]
```

### Thrust Model
```modelica
parameter Real T_max = 100000.0;                         // Max thrust [N]
parameter Real Isp = 300.0;                              // Specific impulse [s]
parameter Real tau_thrust = 0.1;                         // Magnitude time constant [s]
parameter Real tau_direction = 0.05;                     // Direction time constant [s]
parameter Real x_thrust = -6.0;                          // Thrust point from nose [m]
```

### Aerodynamics
```modelica
parameter Real S_ref = 1.0;                              // Reference area [m²]
parameter Real L_ref = 10.0;                             // Reference length [m]
parameter Real D_ref = 1.0;                              // Reference diameter [m]
```

## Customizing Aerodynamic Coefficients

The aerodynamic coefficients are currently **PLACEHOLDERS** and should be replaced with actual data. Modify the `AerodynamicsModel` equations:

```modelica
// Current placeholder (in AerodynamicsModel):
CD = 0.15 + 0.3*alpha^2 + 0.1*Mach;
CL = 1.5*sin(2*alpha);
CY = -0.5*beta;
Cl = -0.1*beta - 0.05*omega_body[1]*D_ref/max(V_mag, 1.0);
Cm = -0.5*alpha - 0.1*omega_body[2]*L_ref/max(V_mag, 1.0);
Cn = 0.1*beta - 0.05*omega_body[3]*L_ref/max(V_mag, 1.0);

// Replace with your data, e.g.:
CD = interpolateTable(CD_table, alpha, Mach);
CL = interpolateTable(CL_table, alpha, Mach);
// etc.
```

You can use Modelica's `CombiTable2D` for 2D interpolation of wind tunnel or CFD data.

## Example Usage

### Simple Thrust Profile

```modelica
model MyRocketFlight
  extends Rocket6DOF.Rocket;
  
equation
  // Constant thrust for 60 seconds
  if time < 60 then
    T_cmd = 75000.0;  // 75 kN
    u_thrust_cmd = {1.0, 0.0, 0.0};  // Pure axial
  else
    T_cmd = 0.0;
    u_thrust_cmd = {1.0, 0.0, 0.0};
  end if;
  
end MyRocketFlight;
```

### Thrust Vector Control Example

```modelica
model ThrustVectorControlExample
  extends Rocket6DOF.Rocket;
  
  Real gimbal_pitch;  // Pitch gimbal angle [rad]
  Real gimbal_yaw;    // Yaw gimbal angle [rad]
  
equation
  // Thrust magnitude
  T_cmd = if time < 30 then 80000.0 else 0.0;
  
  // Sinusoidal gimbal motion for demonstration
  gimbal_pitch = 0.05 * sin(2*3.14159*0.1*time);  // ±0.05 rad at 0.1 Hz
  gimbal_yaw = 0.0;
  
  // Convert gimbal angles to thrust direction
  u_thrust_cmd[1] = cos(gimbal_pitch) * cos(gimbal_yaw);
  u_thrust_cmd[2] = sin(gimbal_yaw);
  u_thrust_cmd[3] = -sin(gimbal_pitch) * cos(gimbal_yaw);
  
end ThrustVectorControlExample;
```

### Closed-Loop Control

For attitude control, create a controller that computes desired thrust direction:

```modelica
model ControlledRocket
  extends Rocket6DOF.Rocket;
  
  // Desired attitude
  parameter Real euler_desired[3] = {0, 0.1, 0};  // 0.1 rad pitch up
  
  Real euler_error[3];
  Real gimbal_cmd[2];  // [pitch, yaw] gimbal commands
  
equation
  // Simple P-controller on Euler angles
  euler_error = euler_desired - euler_ECEF;
  
  gimbal_cmd[1] = 0.5 * euler_error[2];  // Pitch control
  gimbal_cmd[2] = 0.5 * euler_error[1];  // Yaw control
  
  // Limit gimbal angles
  gimbal_cmd[1] = max(-0.1, min(0.1, gimbal_cmd[1]));
  gimbal_cmd[2] = max(-0.1, min(0.1, gimbal_cmd[2]));
  
  // Convert to thrust direction
  u_thrust_cmd[1] = cos(gimbal_cmd[1]) * cos(gimbal_cmd[2]);
  u_thrust_cmd[2] = sin(gimbal_cmd[2]);
  u_thrust_cmd[3] = -sin(gimbal_cmd[1]) * cos(gimbal_cmd[2]);
  
  // Thrust profile
  T_cmd = if time < 60 then 75000 else 0;
  
end ControlledRocket;
```

## Simulation Tips

1. **Solver Selection**: Use DASSL or CVODE for stiff ODEs
2. **Tolerance**: Start with `Tolerance=1e-6`, tighten if needed
3. **Integration Step**: Let solver choose automatically, or use `Interval=0.01` for 100 Hz output
4. **Quaternion Drift**: For long simulations, may need to add normalization constraint

### Example Simulation Settings
```modelica
annotation(experiment(
  StartTime=0, 
  StopTime=200, 
  Tolerance=1e-6,
  Interval=0.01
));
```

## Validation Checklist

Before using for analysis, verify:

- [ ] Replace aerodynamic coefficient placeholders with real data
- [ ] Verify mass properties (dry mass, fuel mass, CoM positions, inertias)
- [ ] Check thrust parameters (Isp, T_max, response times)
- [ ] Validate atmosphere model for your altitude range
- [ ] Verify initial conditions match your scenario
- [ ] Check coordinate frame conventions match your expectations

## Extending the Model

### Adding J2 Gravity Perturbation

In the Rocket model, replace:
```modelica
F_gravity_ECI = -Constants.mu * mass_model.m_total * r_ECI / r_mag^3;
```

With:
```modelica
// Add to Constants
constant Real J2 = 1.08263e-3;

// In Rocket model
Real J2_factor;
J2_factor = 1.5 * J2 * (Constants.R_earth/r_mag)^2;
F_gravity_ECI = -Constants.mu * mass_model.m_total / r_mag^3 * (
  r_ECI * (1 - J2_factor * (5*(r_ECI[3]/r_mag)^2 - 1)) +
  {0, 0, 2*J2_factor*r_ECI[3]}
);
```

### Adding Sensor Models

Create IMU, GPS, and other sensor models that read the rocket states and add noise/dynamics.

### Adding Flexible Body Dynamics

Extend the model with modal coordinates for structural flexibility.

## Troubleshooting

### Quaternion Normalization
If quaternion norm drifts, add constraint:
```modelica
0 = q[1]^2 + q[2]^2 + q[3]^2 + q[4]^2 - 1;
```

### Numerical Issues
- Reduce tolerances
- Use better solver (CVODE, IDA)
- Check for discontinuities in thrust/aero models
- Ensure mass never becomes zero/negative

### Performance
- Simplify aerodynamic coefficient calculations
- Use lookup tables instead of complex functions
- Reduce output interval if generating large datasets

## References

- WGS84 Coordinate System: NIMA TR8350.2
- Quaternion Kinematics: Markley & Crassidis, "Fundamentals of Spacecraft Attitude Determination and Control"
- Rocket Dynamics: Tewari, "Atmospheric and Space Flight Dynamics"

## License

This model is provided as-is for educational and research purposes.
