#!/usr/bin/env python3
"""
Rocket 6-DOF Simulation Analysis and Visualization

This script loads simulation results from the Modelica rocket model and
creates comprehensive plots for trajectory, attitude, forces, and performance.

Usage:
    python analyze_rocket_sim.py <result_file.mat>
    
Requirements:
    - numpy
    - matplotlib
    - scipy (for .mat file loading)
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.io import loadmat
import sys
import os

# Constants
R_EARTH = 6378137.0  # WGS84 equatorial radius [m]
MU_EARTH = 3.986004418e14  # Earth gravitational parameter [m^3/s^2]


def load_results(filename):
    """Load Modelica simulation results from .mat file"""
    try:
        data = loadmat(filename)
        return data
    except Exception as e:
        print(f"Error loading file: {e}")
        sys.exit(1)


def extract_variable(data, varname):
    """Extract variable from Modelica results"""
    # Modelica often stores variables with special naming
    for key in data.keys():
        if varname in key:
            return np.squeeze(data[key])
    return None


def plot_trajectory_3d(time, r_ECEF, altitude):
    """Plot 3D trajectory"""
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # Convert ECEF to km for plotting
    x = r_ECEF[:, 0] / 1000
    y = r_ECEF[:, 1] / 1000
    z = r_ECEF[:, 2] / 1000
    
    # Plot trajectory colored by altitude
    scatter = ax.scatter(x, y, z, c=altitude/1000, cmap='viridis', s=1)
    
    # Draw Earth sphere
    u = np.linspace(0, 2 * np.pi, 50)
    v = np.linspace(0, np.pi, 50)
    x_sphere = R_EARTH/1000 * np.outer(np.cos(u), np.sin(v))
    y_sphere = R_EARTH/1000 * np.outer(np.sin(u), np.sin(v))
    z_sphere = R_EARTH/1000 * np.outer(np.ones(np.size(u)), np.cos(v))
    ax.plot_surface(x_sphere, y_sphere, z_sphere, color='lightblue', alpha=0.3)
    
    ax.set_xlabel('X [km]')
    ax.set_ylabel('Y [km]')
    ax.set_zlabel('Z [km]')
    ax.set_title('Rocket Trajectory in ECEF Frame')
    
    cbar = plt.colorbar(scatter, ax=ax, pad=0.1)
    cbar.set_label('Altitude [km]')
    
    ax.set_box_aspect([1,1,1])
    
    return fig


def plot_position_velocity(time, r_ECEF, v_ECEF, altitude):
    """Plot position and velocity components"""
    fig, axes = plt.subplots(3, 2, figsize=(14, 10))
    
    # Position components
    axes[0, 0].plot(time, r_ECEF[:, 0]/1000, 'r-', label='X')
    axes[0, 0].plot(time, r_ECEF[:, 1]/1000, 'g-', label='Y')
    axes[0, 0].plot(time, r_ECEF[:, 2]/1000, 'b-', label='Z')
    axes[0, 0].set_ylabel('Position [km]')
    axes[0, 0].set_title('Position in ECEF')
    axes[0, 0].legend()
    axes[0, 0].grid(True)
    
    # Velocity components
    axes[1, 0].plot(time, v_ECEF[:, 0], 'r-', label='Vx')
    axes[1, 0].plot(time, v_ECEF[:, 1], 'g-', label='Vy')
    axes[1, 0].plot(time, v_ECEF[:, 2], 'b-', label='Vz')
    axes[1, 0].set_ylabel('Velocity [m/s]')
    axes[1, 0].set_title('Velocity in ECEF')
    axes[1, 0].legend()
    axes[1, 0].grid(True)
    
    # Altitude
    axes[2, 0].plot(time, altitude/1000, 'k-')
    axes[2, 0].set_xlabel('Time [s]')
    axes[2, 0].set_ylabel('Altitude [km]')
    axes[2, 0].set_title('Altitude Above Sea Level')
    axes[2, 0].grid(True)
    
    # Speed
    speed = np.sqrt(np.sum(v_ECEF**2, axis=1))
    axes[0, 1].plot(time, speed, 'k-')
    axes[0, 1].set_ylabel('Speed [m/s]')
    axes[0, 1].set_title('Total Velocity Magnitude')
    axes[0, 1].grid(True)
    
    # Orbital energy
    r_mag = np.sqrt(np.sum(r_ECEF**2, axis=1))
    energy = 0.5 * speed**2 - MU_EARTH / r_mag
    axes[1, 1].plot(time, energy/1e6, 'purple')
    axes[1, 1].set_ylabel('Specific Energy [MJ/kg]')
    axes[1, 1].set_title('Specific Orbital Energy')
    axes[1, 1].grid(True)
    
    # Flight path angle
    r_unit = r_ECEF / r_mag[:, np.newaxis]
    v_radial = np.sum(r_unit * v_ECEF, axis=1)
    fpa = np.arcsin(v_radial / (speed + 1e-10)) * 180/np.pi
    axes[2, 1].plot(time, fpa, 'orange')
    axes[2, 1].set_xlabel('Time [s]')
    axes[2, 1].set_ylabel('Flight Path Angle [deg]')
    axes[2, 1].set_title('Flight Path Angle')
    axes[2, 1].grid(True)
    
    plt.tight_layout()
    return fig


def plot_attitude(time, euler, omega_body):
    """Plot attitude and angular velocity"""
    fig, axes = plt.subplots(2, 1, figsize=(12, 8))
    
    # Euler angles
    axes[0].plot(time, euler[:, 0]*180/np.pi, 'r-', label='Yaw')
    axes[0].plot(time, euler[:, 1]*180/np.pi, 'g-', label='Pitch')
    axes[0].plot(time, euler[:, 2]*180/np.pi, 'b-', label='Roll')
    axes[0].set_ylabel('Angle [deg]')
    axes[0].set_title('Euler Angles (ECEF Frame)')
    axes[0].legend()
    axes[0].grid(True)
    
    # Angular velocity
    axes[1].plot(time, omega_body[:, 0]*180/np.pi, 'r-', label='ωx (Roll rate)')
    axes[1].plot(time, omega_body[:, 1]*180/np.pi, 'g-', label='ωy (Pitch rate)')
    axes[1].plot(time, omega_body[:, 2]*180/np.pi, 'b-', label='ωz (Yaw rate)')
    axes[1].set_xlabel('Time [s]')
    axes[1].set_ylabel('Angular Velocity [deg/s]')
    axes[1].set_title('Angular Velocity (Body Frame)')
    axes[1].legend()
    axes[1].grid(True)
    
    plt.tight_layout()
    return fig


def plot_mass_properties(time, m_total, x_cm):
    """Plot mass and center of mass"""
    fig, axes = plt.subplots(2, 1, figsize=(12, 6))
    
    # Total mass
    axes[0].plot(time, m_total, 'k-', linewidth=2)
    axes[0].set_ylabel('Total Mass [kg]')
    axes[0].set_title('Rocket Total Mass')
    axes[0].grid(True)
    
    # Center of mass position
    axes[1].plot(time, x_cm, 'b-', linewidth=2)
    axes[1].set_xlabel('Time [s]')
    axes[1].set_ylabel('CoM Position [m]')
    axes[1].set_title('Center of Mass Position from Nose')
    axes[1].grid(True)
    
    plt.tight_layout()
    return fig


def plot_forces_moments(time, F_thrust, F_aero, M_total):
    """Plot forces and moments"""
    fig, axes = plt.subplots(2, 2, figsize=(14, 8))
    
    # Thrust force components
    axes[0, 0].plot(time, F_thrust[:, 0]/1000, 'r-', label='Fx')
    axes[0, 0].plot(time, F_thrust[:, 1]/1000, 'g-', label='Fy')
    axes[0, 0].plot(time, F_thrust[:, 2]/1000, 'b-', label='Fz')
    axes[0, 0].set_ylabel('Thrust Force [kN]')
    axes[0, 0].set_title('Thrust Force (Body Frame)')
    axes[0, 0].legend()
    axes[0, 0].grid(True)
    
    # Thrust magnitude
    T_mag = np.sqrt(np.sum(F_thrust**2, axis=1))
    axes[0, 1].plot(time, T_mag/1000, 'k-', linewidth=2)
    axes[0, 1].set_ylabel('Thrust Magnitude [kN]')
    axes[0, 1].set_title('Total Thrust Magnitude')
    axes[0, 1].grid(True)
    
    # Aerodynamic force components
    axes[1, 0].plot(time, F_aero[:, 0]/1000, 'r-', label='Fx (Drag)')
    axes[1, 0].plot(time, F_aero[:, 1]/1000, 'g-', label='Fy (Side)')
    axes[1, 0].plot(time, F_aero[:, 2]/1000, 'b-', label='Fz (Lift)')
    axes[1, 0].set_xlabel('Time [s]')
    axes[1, 0].set_ylabel('Aero Force [kN]')
    axes[1, 0].set_title('Aerodynamic Force (Body Frame)')
    axes[1, 0].legend()
    axes[1, 0].grid(True)
    
    # Total moments
    axes[1, 1].plot(time, M_total[:, 0]/1000, 'r-', label='Mx (Roll)')
    axes[1, 1].plot(time, M_total[:, 1]/1000, 'g-', label='My (Pitch)')
    axes[1, 1].plot(time, M_total[:, 2]/1000, 'b-', label='Mz (Yaw)')
    axes[1, 1].set_xlabel('Time [s]')
    axes[1, 1].set_ylabel('Moment [kN·m]')
    axes[1, 1].set_title('Total Moments (Body Frame)')
    axes[1, 1].legend()
    axes[1, 1].grid(True)
    
    plt.tight_layout()
    return fig


def plot_aerodynamics(time, alpha, beta, Mach, q_dyn, CD, CL):
    """Plot aerodynamic parameters"""
    fig, axes = plt.subplots(3, 2, figsize=(14, 10))
    
    # Angle of attack
    axes[0, 0].plot(time, alpha*180/np.pi, 'r-')
    axes[0, 0].set_ylabel('Angle of Attack [deg]')
    axes[0, 0].set_title('Angle of Attack')
    axes[0, 0].grid(True)
    
    # Sideslip angle
    axes[0, 1].plot(time, beta*180/np.pi, 'g-')
    axes[0, 1].set_ylabel('Sideslip Angle [deg]')
    axes[0, 1].set_title('Sideslip Angle')
    axes[0, 1].grid(True)
    
    # Mach number
    axes[1, 0].plot(time, Mach, 'b-')
    axes[1, 0].set_ylabel('Mach Number')
    axes[1, 0].set_title('Mach Number')
    axes[1, 0].grid(True)
    
    # Dynamic pressure
    axes[1, 1].plot(time, q_dyn/1000, 'purple')
    axes[1, 1].set_ylabel('Dynamic Pressure [kPa]')
    axes[1, 1].set_title('Dynamic Pressure')
    axes[1, 1].grid(True)
    
    # Drag coefficient
    axes[2, 0].plot(time, CD, 'orange')
    axes[2, 0].set_xlabel('Time [s]')
    axes[2, 0].set_ylabel('CD')
    axes[2, 0].set_title('Drag Coefficient')
    axes[2, 0].grid(True)
    
    # Lift coefficient
    axes[2, 1].plot(time, CL, 'cyan')
    axes[2, 1].set_xlabel('Time [s]')
    axes[2, 1].set_ylabel('CL')
    axes[2, 1].set_title('Lift Coefficient')
    axes[2, 1].grid(True)
    
    plt.tight_layout()
    return fig


def plot_ground_track(lat, lon):
    """Plot ground track on map projection"""
    fig, ax = plt.subplots(figsize=(14, 7))
    
    # Convert to degrees
    lat_deg = lat * 180/np.pi
    lon_deg = lon * 180/np.pi
    
    # Plot ground track
    scatter = ax.scatter(lon_deg, lat_deg, c=np.arange(len(lat)), 
                        cmap='viridis', s=2)
    
    # Mark start and end
    ax.plot(lon_deg[0], lat_deg[0], 'go', markersize=10, label='Start')
    ax.plot(lon_deg[-1], lat_deg[-1], 'ro', markersize=10, label='End')
    
    ax.set_xlabel('Longitude [deg]')
    ax.set_ylabel('Latitude [deg]')
    ax.set_title('Ground Track')
    ax.grid(True)
    ax.legend()
    
    # Set reasonable limits
    ax.set_xlim([-180, 180])
    ax.set_ylim([-90, 90])
    
    cbar = plt.colorbar(scatter, ax=ax)
    cbar.set_label('Time Step')
    
    return fig


def generate_summary_report(data, time, r_ECEF, v_ECEF, altitude):
    """Generate text summary of simulation"""
    
    print("\n" + "="*60)
    print("ROCKET SIMULATION SUMMARY")
    print("="*60)
    
    print(f"\nSimulation Duration: {time[-1]:.2f} s")
    print(f"Time Steps: {len(time)}")
    
    print(f"\nInitial Conditions:")
    print(f"  Altitude: {altitude[0]/1000:.2f} km")
    speed_0 = np.sqrt(np.sum(v_ECEF[0]**2))
    print(f"  Speed: {speed_0:.2f} m/s")
    
    print(f"\nFinal Conditions:")
    print(f"  Altitude: {altitude[-1]/1000:.2f} km")
    speed_f = np.sqrt(np.sum(v_ECEF[-1]**2))
    print(f"  Speed: {speed_f:.2f} m/s")
    
    print(f"\nMaximum Values:")
    print(f"  Peak Altitude: {np.max(altitude)/1000:.2f} km")
    speed = np.sqrt(np.sum(v_ECEF**2, axis=1))
    print(f"  Peak Speed: {np.max(speed):.2f} m/s")
    
    r_mag = np.sqrt(np.sum(r_ECEF**2, axis=1))
    energy = 0.5 * speed**2 - MU_EARTH / r_mag
    print(f"  Final Specific Energy: {energy[-1]/1e6:.2f} MJ/kg")
    
    print("\n" + "="*60 + "\n")


def main():
    if len(sys.argv) < 2:
        print("Usage: python analyze_rocket_sim.py <result_file.mat>")
        sys.exit(1)
    
    filename = sys.argv[1]
    
    if not os.path.exists(filename):
        print(f"Error: File '{filename}' not found")
        sys.exit(1)
    
    print(f"Loading results from: {filename}")
    data = load_results(filename)
    
    # Extract time vector (common to all variables)
    time = extract_variable(data, 'time')
    if time is None:
        print("Error: Could not find time vector in results")
        sys.exit(1)
    
    # Extract key variables - adjust variable names based on actual output
    # These are typical Modelica naming conventions
    print("Extracting variables...")
    
    # Try to extract main variables (names may vary)
    r_ECEF = np.column_stack([
        extract_variable(data, 'r_ECEF[1]'),
        extract_variable(data, 'r_ECEF[2]'),
        extract_variable(data, 'r_ECEF[3]')
    ])
    
    v_ECEF = np.column_stack([
        extract_variable(data, 'v_ECEF[1]'),
        extract_variable(data, 'v_ECEF[2]'),
        extract_variable(data, 'v_ECEF[3]')
    ])
    
    altitude = extract_variable(data, 'altitude')
    
    # Create output directory
    output_dir = "rocket_analysis_plots"
    os.makedirs(output_dir, exist_ok=True)
    
    print(f"Generating plots in: {output_dir}/")
    
    # Generate plots
    if r_ECEF is not None and altitude is not None:
        fig = plot_trajectory_3d(time, r_ECEF, altitude)
        fig.savefig(f"{output_dir}/trajectory_3d.png", dpi=150, bbox_inches='tight')
        plt.close(fig)
        print("  ✓ 3D Trajectory")
    
    if r_ECEF is not None and v_ECEF is not None and altitude is not None:
        fig = plot_position_velocity(time, r_ECEF, v_ECEF, altitude)
        fig.savefig(f"{output_dir}/position_velocity.png", dpi=150, bbox_inches='tight')
        plt.close(fig)
        print("  ✓ Position & Velocity")
        
        generate_summary_report(data, time, r_ECEF, v_ECEF, altitude)
    
    # Add more plot generations as needed based on available data
    
    print(f"\nAnalysis complete! Plots saved to: {output_dir}/")


if __name__ == "__main__":
    main()
