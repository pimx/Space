# 6-DOF Rocket Model - Project Summary

## What Was Created

I've developed a comprehensive 6-degree-of-freedom (6-DOF) rocket dynamics model in Modelica that meets all your specifications. Here's what's included:

### Core Files

1. **Rocket6DOF.mo** - Main Modelica package containing:
   - Complete 6-DOF rocket dynamics model
   - Mass properties model with fuel depletion
   - Thrust model with magnitude and direction control
   - Aerodynamic model with placeholder coefficients
   - Coordinate transformation utilities
   - Atmosphere model

2. **RocketFlightExample.mo** - Example simulation showing how to use the model

3. **README.md** - Comprehensive documentation with:
   - Model structure and features
   - All parameters and how to customize them
   - Usage examples
   - Simulation tips
   - Troubleshooting guide

4. **CoordinateSystems_Reference.md** - Detailed reference on:
   - All coordinate frame definitions
   - Transformation equations and implementations
   - Quaternion operations
   - Common pitfalls and validation checks

5. **analyze_rocket_sim.py** - Python script for post-processing with:
   - 3D trajectory visualization
   - Position/velocity/attitude plots
   - Forces and moments analysis
   - Ground track plotting
   - Performance summary

## Model Features Implemented

### ✅ Dynamics & Integration
- [x] Integration in ECI (Earth-Centered Inertial) frame
- [x] Position and velocity states in ECI
- [x] Quaternion-based attitude representation (avoids gimbal lock)
- [x] Angular velocity in body frame

### ✅ Coordinate Frames
- [x] Body frame: X-forward (nose), Y-right, Z-down
- [x] ECI to ECEF transformations
- [x] ECEF outputs with WGS84 geodetic coordinates
- [x] Euler angles output (yaw, pitch, roll)

### ✅ Gravity
- [x] Simple point-mass Earth gravity (μ/r²)
- [x] Computed in ECI frame

### ✅ Aerodynamics
- [x] Full 6-DOF aerodynamic forces (drag, lift, side force)
- [x] Full 6-DOF aerodynamic moments (roll, pitch, yaw)
- [x] Angle of attack (α) and sideslip (β) calculation
- [x] Mach number computation
- [x] Dynamic pressure calculation
- [x] **Placeholder coefficients** - ready for your actual aero data

### ✅ Mass Properties
- [x] Fuel depletion model integrated with thrust
- [x] Center of mass shift during fuel burn
- [x] Inertia tensor changes with fuel consumption
- [x] Parallel axis theorem for proper inertia calculation

### ✅ Thrust
- [x] Direct thrust vector control (magnitude + direction)
- [x] First-order dynamics for thrust magnitude (τ = 0.1 s)
- [x] First-order dynamics for thrust direction (τ = 0.05 s)
- [x] Automatic normalization of direction vector
- [x] Thrust moments from offset application point
- [x] Specific impulse-based propellant mass flow

### ✅ Outputs
- [x] Position and velocity in ECEF frame
- [x] Euler angles (yaw, pitch, roll)
- [x] Angular velocity in body frame
- [x] Geodetic coordinates (latitude, longitude, altitude)
- [x] All intermediate variables accessible

## Quick Start Guide

### 1. Loading the Model

In OpenModelica or Dymola:
```
loadFile("Rocket6DOF.mo");
loadFile("RocketFlightExample.mo");
```

### 2. Running the Example

```
simulate(RocketFlightExample, stopTime=100)
```

### 3. Basic Customization

To create your own scenario, extend the Rocket model:

```modelica
model MyRocketFlight
  extends Rocket6DOF.Rocket;
  
  // Override initial conditions
  parameter Real r0_ECI[3] = {6478137, 0, 0}; // 100 km altitude
  parameter Real v0_ECI[3] = {0, 7500, 0};    // ~orbital velocity
  
equation
  // Define your thrust profile
  if time < 60 then
    T_cmd = 80000.0;              // 80 kN thrust
    u_thrust_cmd = {1.0, 0.0, -0.05}; // Slight pitch up
  else
    T_cmd = 0.0;
    u_thrust_cmd = {1.0, 0.0, 0.0};
  end if;
  
end MyRocketFlight;
```

### 4. Analyzing Results

After simulation, export to .mat file and use the Python script:

```bash
python analyze_rocket_sim.py simulation_results.mat
```

This generates comprehensive plots in `rocket_analysis_plots/` directory.

## Key Parameters to Customize

### Your Rocket's Properties

In the model file, find and modify:

```modelica
// Mass properties
m_dry = 1000.0;              // Your dry mass [kg]
m_fuel_initial = 9000.0;     // Your fuel mass [kg]
x_cm_dry = 0.0;              // Your dry CoM [m from nose]

// Inertia tensors (body frame, diagonal for axisymmetric)
I_dry[3,3] = [1000, 0, 0; 
              0, 10000, 0; 
              0, 0, 10000];  // [kg·m²]

// Engine properties  
T_max = 100000.0;            // Your max thrust [N]
Isp = 300.0;                 // Your specific impulse [s]
x_thrust = -6.0;             // Thrust point location [m from nose]

// Aerodynamic reference
S_ref = 1.0;                 // Your reference area [m²]
L_ref = 10.0;                // Your reference length [m]
```

### **CRITICAL: Replace Aerodynamic Coefficients**

The aerodynamic coefficients are placeholders! In `AerodynamicsModel`, replace:

```modelica
// Current PLACEHOLDER:
CD = 0.15 + 0.3*alpha^2 + 0.1*Mach;
CL = 1.5*sin(2*alpha);
// ... etc

// Replace with YOUR data (example using lookup table):
CD = CombiTable2D(CD_table, alpha, Mach);
CL = CombiTable2D(CL_table, alpha, Mach);
// ... etc
```

## Model Architecture

```
Rocket (Main Model)
├── MassPropertiesModel
│   ├── Fuel depletion integration
│   ├── CoM calculation
│   └── Inertia tensor with parallel axis theorem
│
├── ThrustModel
│   ├── Thrust magnitude dynamics
│   ├── Direction vector dynamics
│   ├── Thrust forces in body frame
│   ├── Thrust moments from lever arm
│   └── Mass flow calculation
│
└── AerodynamicsModel
    ├── Aerodynamic angles (α, β)
    ├── Mach number
    ├── Aerodynamic coefficients (PLACEHOLDER)
    ├── Aerodynamic forces in body frame
    └── Aerodynamic moments in body frame

Integration performed in ECI frame:
├── Translational dynamics: F = ma (ECI)
├── Rotational dynamics: I·ω̇ + ω×(I·ω) = M (body frame)
├── Quaternion kinematics: q̇ = 0.5 q ⊗ [0,ω] (body frame)
└── Transformations to ECEF for output
```

## What You Need to Add

1. **Aerodynamic Data**:
   - Replace placeholder coefficients in `AerodynamicsModel`
   - Use CombiTable2D for tabular data from CFD/wind tunnel
   - Or implement analytical functions for your specific rocket

2. **Control System** (if desired):
   - Add PID or other controller for thrust vectoring
   - Command T_cmd and u_thrust_cmd based on guidance laws
   - See examples in README.md

3. **Initial Conditions**:
   - Set appropriate r0_ECI, v0_ECI for your scenario
   - Set initial attitude q0 and angular velocity omega0_body

4. **Validation**:
   - Compare with flight data or other validated simulations
   - Check energy conservation for vacuum coast phases
   - Verify coordinate transformations with known test cases

## Simulation Recommendations

### Solver Settings
- **Solver**: DASSL or CVODE (for stiff systems)
- **Tolerance**: 1e-6 (tighten to 1e-8 for high-precision)
- **Output Interval**: 0.01 s (100 Hz) for smooth plots

### Common Issues & Solutions

**Issue**: Quaternion norm drift
**Solution**: Add normalization constraint or periodically re-normalize

**Issue**: Numerical instability at high Mach
**Solution**: Check aerodynamic coefficient smoothness, reduce tolerance

**Issue**: Mass becomes negative
**Solution**: Add `max(0, m_fuel)` in calculations (already implemented)

**Issue**: Gimbal lock in Euler angles
**Solution**: Use quaternion outputs directly, Euler angles are for display only

## Advanced Features You Can Add

### 1. J2 Gravity Perturbation
See README.md for implementation

### 2. Multiple Engine Model
Extend ThrustModel to array of engines

### 3. Flexible Body Dynamics
Add modal coordinates for structural bending

### 4. Sensor Models
Create IMU, GPS, and other sensor blocks that read states

### 5. Wind Model
Add wind velocity to atmosphere model, affects aerodynamics

### 6. Complex Atmosphere
Replace exponential model with standard atmosphere (ISA)

## File Descriptions

| File | Purpose | Size |
|------|---------|------|
| Rocket6DOF.mo | Complete model package | ~600 lines |
| RocketFlightExample.mo | Usage example | ~30 lines |
| README.md | Documentation | ~400 lines |
| CoordinateSystems_Reference.md | Frame transformations | ~400 lines |
| analyze_rocket_sim.py | Post-processing | ~500 lines |

## Next Steps

1. **Immediate**: Review the model parameters and adjust to your rocket
2. **Critical**: Replace aerodynamic coefficient placeholders with real data
3. **Recommended**: Run RocketFlightExample to verify installation
4. **Optional**: Add control system for closed-loop guidance
5. **Validation**: Compare with known test cases or flight data

## Support & References

- **Modelica Language**: https://modelica.org/
- **OpenModelica**: https://openmodelica.org/
- **WGS84 Standard**: NIMA TR8350.2
- **Quaternion Math**: "Quaternions and Rotation Sequences" - Kuipers
- **Spacecraft Dynamics**: "Fundamentals of Astrodynamics" - Bate, Mueller, White

## Summary

You now have a complete, modular, well-documented 6-DOF rocket simulation model that:
- ✅ Integrates in ECI frame with proper coordinate transformations
- ✅ Outputs in ECEF with geodetic coordinates
- ✅ Uses body frame for forces/moments as specified
- ✅ Includes thrust vector control with dynamics
- ✅ Models fuel depletion with CoM shift and inertia changes
- ✅ Has placeholder aerodynamics ready for your data
- ✅ Provides comprehensive documentation and examples

The model is ready to customize for your specific rocket and simulation scenarios. Simply adjust the parameters, add your aerodynamic data, and you're ready to simulate!

---
Created: November 2025
Model Complexity: ~600 lines of Modelica + utilities
Documentation: ~1000+ lines
