# Quick Start Checklist

## ⚡ Get Started in 5 Minutes

### Step 1: Load the Model
```modelica
// In OpenModelica or Dymola:
loadFile("Rocket6DOF.mo");
loadFile("RocketFlightExample.mo");
```

### Step 2: Run Example Simulation
```modelica
simulate(RocketFlightExample, stopTime=100, tolerance=1e-6);
```

### Step 3: View Results
- Plot `altitude` vs `time` to see rocket climb
- Plot `euler_ECEF[2]*180/3.14159` to see pitch angle
- Plot `mass_model.m_total` to see fuel depletion

## 🎯 Before First Real Use

### Must Do (Critical):
- [ ] **Replace aerodynamic coefficients** in `AerodynamicsModel`
  - Current values are PLACEHOLDERS
  - Need your rocket's actual CD, CL, CY, Cl, Cm, Cn data
  - Location: Lines 200-220 in Rocket6DOF.mo

- [ ] **Set your rocket's mass properties**
  - `m_dry`: Your dry mass [kg]
  - `m_fuel_initial`: Your fuel mass [kg]
  - `I_dry[3,3]`: Your inertia tensor [kg·m²]
  - Location: MassPropertiesModel parameters

- [ ] **Set your engine parameters**
  - `T_max`: Maximum thrust [N]
  - `Isp`: Specific impulse [s]
  - `x_thrust`: Engine location from nose [m]
  - Location: ThrustModel parameters

### Should Do (Important):
- [ ] **Set initial conditions for your scenario**
  - `r0_ECI`: Starting position [m]
  - `v0_ECI`: Starting velocity [m/s]
  - `q0`: Initial attitude quaternion
  - Location: Rocket model parameters

- [ ] **Define thrust profile**
  - Set `T_cmd` = desired thrust [N]
  - Set `u_thrust_cmd` = direction vector [x,y,z]
  - Location: In your model's equation section

### Nice to Have (Optional):
- [ ] Add control system for thrust vectoring
- [ ] Implement guidance algorithm
- [ ] Add more detailed atmosphere model
- [ ] Include J2 gravity perturbation
- [ ] Create sensor models (IMU, GPS)

## 📋 Parameter Quick Reference

### Initial Conditions (Example Values)
```modelica
// Low Earth orbit example
parameter Real r0_ECI[3] = {6478137, 0, 0};     // 100 km altitude
parameter Real v0_ECI[3] = {0, 7500, 0};        // ~orbital velocity
parameter Real q0[4] = {1, 0, 0, 0};            // Aligned with ECI
parameter Real omega0_body[3] = {0, 0, 0};      // Not spinning
```

### Mass Properties (Example - Replace with yours!)
```modelica
parameter Real m_dry = 1000.0;                  // kg
parameter Real m_fuel_initial = 9000.0;         // kg  
parameter Real x_cm_dry = 0.0;                  // m from nose
parameter Real x_fuel_full = -5.0;              // m from nose
parameter Real I_dry[3,3] = [1000, 0, 0; 
                             0, 10000, 0; 
                             0, 0, 10000];      // kg·m²
```

### Engine Properties (Example - Replace with yours!)
```modelica
parameter Real T_max = 100000.0;                // N (100 kN)
parameter Real Isp = 300.0;                     // s
parameter Real x_thrust = -6.0;                 // m from nose
```

### Aerodynamics (Example - Replace with yours!)
```modelica
parameter Real S_ref = 1.0;                     // m²
parameter Real L_ref = 10.0;                    // m
parameter Real D_ref = 1.0;                     // m
```

## 🎮 Simple Thrust Command Examples

### Constant Thrust for 60 Seconds
```modelica
equation
  if time < 60 then
    T_cmd = 75000.0;              // 75 kN
    u_thrust_cmd = {1, 0, 0};     // Pure axial
  else
    T_cmd = 0.0;
    u_thrust_cmd = {1, 0, 0};
  end if;
```

### Pitch Up Maneuver
```modelica
equation
  T_cmd = 80000.0;
  
  // Pitch up 5 degrees (0.087 rad)
  u_thrust_cmd[1] = cos(0.087);   // X component
  u_thrust_cmd[2] = 0;            // Y component  
  u_thrust_cmd[3] = -sin(0.087);  // Z component (negative = pitch up)
```

### Thrust Vector Control
```modelica
Real gimbal_pitch;
Real gimbal_yaw;

equation
  gimbal_pitch = 0.05 * sin(2*3.14159*0.1*time);  // ±0.05 rad oscillation
  gimbal_yaw = 0.0;
  
  u_thrust_cmd[1] = cos(gimbal_pitch) * cos(gimbal_yaw);
  u_thrust_cmd[2] = sin(gimbal_yaw);
  u_thrust_cmd[3] = -sin(gimbal_pitch) * cos(gimbal_yaw);
  
  T_cmd = 80000.0;
```

## 🔍 Key Variables to Monitor

### Essential Outputs
```
altitude                    // Altitude above sea level [m]
euler_ECEF[1..3]           // Yaw, Pitch, Roll [rad]
omega_body[1..3]           // Angular rates [rad/s]
mass_model.m_total         // Current mass [kg]
r_ECEF[1..3]              // Position in ECEF [m]
v_ECEF[1..3]              // Velocity in ECEF [m/s]
```

### For Debugging
```
q[1..4]                    // Attitude quaternion
thrust_model.T_actual      // Actual thrust [N]
aero_model.alpha           // Angle of attack [rad]
aero_model.Mach            // Mach number
q_dyn                      // Dynamic pressure [Pa]
```

## ⚠️ Common First-Time Issues

### Issue: "Model doesn't compile"
**Fix**: Check that file paths are correct and Rocket6DOF.mo loads first

### Issue: "Simulation fails immediately"
**Fix**: Check initial conditions - make sure altitude > 0 and velocity is reasonable

### Issue: "Quaternion becomes non-unit"
**Fix**: Add normalization or tighten solver tolerance to 1e-8

### Issue: "Results look wrong"
**Fix**: Did you replace the placeholder aerodynamic coefficients?

### Issue: "Mass goes negative"
**Fix**: Already handled with max(0, m_fuel) - check your burn time doesn't exceed fuel

## 📊 Quick Validation Tests

### Test 1: Energy Conservation (Vacuum Coast)
After thrust stops, check that specific energy is constant:
```
E = V²/2 - μ/r
```
Should be constant (within tolerance) during coast phase.

### Test 2: Quaternion Norm
Throughout simulation, check:
```
||q|| = sqrt(q[1]² + q[2]² + q[3]² + q[4]²) ≈ 1.0
```

### Test 3: Mass Conservation
```
m_total(t) = m_dry + m_fuel(0) - ∫ṁ dt
```
Final mass should equal: `m_dry + remaining_fuel`

## 🚀 Ready to Launch!

Once you've completed the "Must Do" items above, you're ready to:
1. Run your first simulation
2. Analyze results with the Python script
3. Iterate on design and control strategies
4. Validate against flight data or other models

## 📖 Where to Look Next

- **Full documentation**: README.md
- **Coordinate systems**: CoordinateSystems_Reference.md  
- **Overall summary**: PROJECT_SUMMARY.md
- **Post-processing**: analyze_rocket_sim.py

## 💡 Pro Tips

1. Start with short simulation times (10-20s) to debug quickly
2. Use `plotParametric(euler_ECEF[2], altitude)` to see pitch vs altitude
3. Export to .mat file for detailed Python analysis
4. Keep solver tolerance at 1e-6 unless you need higher precision
5. Monitor dynamic pressure - peak q is critical for structural loads

---
**Remember**: The aerodynamic coefficients are PLACEHOLDERS - replace them with your rocket's actual data before trusting any results!
