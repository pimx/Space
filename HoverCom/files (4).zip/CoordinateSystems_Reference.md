# Coordinate Systems and Transformations Reference

## Frame Definitions

### 1. ECI (Earth-Centered Inertial)
- **Origin**: Center of Earth
- **Z-axis**: Along Earth's rotation axis, pointing North
- **X-axis**: Points toward vernal equinox (fixed in inertial space)
- **Y-axis**: Completes right-hand rule (in equatorial plane)
- **Properties**: 
  - Non-rotating (inertial)
  - Used for integration of equations of motion
  - Newton's laws apply directly in this frame

### 2. ECEF (Earth-Centered Earth-Fixed)
- **Origin**: Center of Earth
- **Z-axis**: Along Earth's rotation axis, pointing North
- **X-axis**: Points to intersection of prime meridian and equator
- **Y-axis**: Completes right-hand rule (90° East longitude)
- **Properties**:
  - Rotates with Earth at ω_earth = 7.2921159e-5 rad/s
  - Fixed to Earth's surface
  - Used for geodetic coordinates (lat/lon/alt)
  - Convenient for launch site and landing site coordinates

### 3. Body Frame
- **Origin**: Rocket's center of mass
- **X-axis**: Forward, along rocket longitudinal axis (toward nose)
- **Y-axis**: Right (starboard)
- **Z-axis**: Down (completes right-hand rule)
- **Properties**:
  - Moves and rotates with the rocket
  - Aerodynamic and thrust forces naturally expressed here
  - Sensors (IMU) measure in this frame

## Transformation Relationships

### ECI ↔ ECEF

#### Position Transformation
```
r_ECEF = R_z(θ) * r_ECI

where θ = ω_earth * t

R_z(θ) = [cos(θ)   sin(θ)   0]
         [-sin(θ)  cos(θ)   0]
         [0        0        1]
```

**Implementation:**
```
r_ECEF[1] = cos(θ) * r_ECI[1] + sin(θ) * r_ECI[2]
r_ECEF[2] = -sin(θ) * r_ECI[1] + cos(θ) * r_ECI[2]
r_ECEF[3] = r_ECI[3]
```

#### Velocity Transformation
```
v_ECEF = R_z(θ) * v_ECI - ω × r_ECEF

where ω = [0, 0, ω_earth]ᵀ
```

The ω × r term accounts for Earth's rotation contribution.

**Implementation:**
```
v_ECEF_temp = R_z(θ) * v_ECI  (rotate velocity)
v_ECEF[1] = v_ECEF_temp[1] + ω_earth * r_ECEF[2]
v_ECEF[2] = v_ECEF_temp[2] - ω_earth * r_ECEF[1]
v_ECEF[3] = v_ECEF_temp[3]
```

### ECI ↔ Body

Uses quaternion q = [w, x, y, z] representing rotation from ECI to Body frame.

#### Rotation Matrix from Quaternion
```
R_ECI_to_Body = [1-2(y²+z²)   2(xy-wz)     2(xz+wy)  ]
                 [2(xy+wz)     1-2(x²+z²)   2(yz-wx)  ]
                 [2(xz-wy)     2(yz+wx)     1-2(x²+y²)]
```

#### Vector Transformation
```
v_body = R_ECI_to_Body * v_ECI
v_ECI = R_Body_to_ECI * v_body

where R_Body_to_ECI = R_ECI_to_Body^T
```

### Geodetic Coordinates (WGS84)

From ECEF position (x, y, z) to geodetic coordinates:

```
Longitude: λ = atan2(y, x)

Latitude: φ (iterative algorithm)
  p = √(x² + y²)
  θ = atan2(z·a, p·b)
  φ = atan2(z + e'²·b·sin³(θ), p - e²·a·cos³(θ))
  
Altitude: h = p/cos(φ) - N

where:
  a = 6378137.0 m (equatorial radius)
  f = 1/298.257223563 (flattening)
  b = a(1-f) (polar radius)
  e² = 2f - f² (eccentricity squared)
  e'² = e²/(1-e²)
  N = a/√(1 - e²sin²(φ)) (radius of curvature)
```

## Quaternion Operations

### Quaternion Representation
- **Scalar part**: w (real component)
- **Vector part**: [x, y, z] (imaginary components)
- **Notation**: q = [w, x, y, z]
- **Unit quaternion**: w² + x² + y² + z² = 1

### Quaternion Kinematics

The quaternion derivative is:
```
dq/dt = 0.5 * q ⊗ [0, ωx, ωy, ωz]

where ⊗ is quaternion multiplication
```

**Implementation:**
```
dq/dt[1] = 0.5 * (-q[2]*ω[1] - q[3]*ω[2] - q[4]*ω[3])
dq/dt[2] = 0.5 * ( q[1]*ω[1] + q[3]*ω[3] - q[4]*ω[2])
dq/dt[3] = 0.5 * ( q[1]*ω[2] - q[2]*ω[3] + q[4]*ω[1])
dq/dt[4] = 0.5 * ( q[1]*ω[3] + q[2]*ω[2] - q[3]*ω[1])
```

### Quaternion to Euler Angles (Z-Y-X sequence)

```
yaw (ψ) = atan2(2(wx + yz), 1 - 2(y² + x²))
pitch (θ) = asin(2(wy - zx))
roll (φ) = atan2(2(wz + xy), 1 - 2(z² + y²))
```

### Euler Angles to Quaternion (Z-Y-X sequence)

Given roll (φ), pitch (θ), yaw (ψ):

```
cy = cos(ψ/2)
sy = sin(ψ/2)
cp = cos(θ/2)
sp = sin(θ/2)
cr = cos(φ/2)
sr = sin(φ/2)

w = cr*cp*cy + sr*sp*sy
x = sr*cp*cy - cr*sp*sy
y = cr*sp*cy + sr*cp*sy
z = cr*cp*sy - sr*sp*cy
```

## Force and Moment Transformations

### Thrust Forces
- **Commanded in**: Body frame (natural for TVC)
- **Need in**: ECI frame (for equations of motion)
- **Transformation**: `F_thrust_ECI = R_Body_to_ECI * F_thrust_body`

### Aerodynamic Forces
- **Computed in**: Body frame (natural for angle of attack, sideslip)
- **Need in**: ECI frame (for equations of motion)
- **Transformation**: `F_aero_ECI = R_Body_to_ECI * F_aero_body`

### Thrust Moments
- **Applied at**: Thrust application point (x_thrust, 0, 0) in body frame
- **CoM at**: (x_cm, 0, 0) in body frame
- **Lever arm**: r = [x_thrust - x_cm, 0, 0]
- **Moment**: M = r × F_thrust

```
M[1] = 0  (no roll moment from axial offset)
M[2] = -(x_thrust - x_cm) * F_thrust[3]  (pitch from Z-force)
M[3] = (x_thrust - x_cm) * F_thrust[2]   (yaw from Y-force)
```

## Angular Velocity Relationships

### Euler's Rotation Equation (Body Frame)
```
I·ω̇ + ω × (I·ω) = M

where:
  I = inertia tensor in body frame
  ω = angular velocity in body frame [ωx, ωy, ωz]
  M = total moment in body frame
```

**Solving for angular acceleration:**
```
ω̇ = I⁻¹ · (M - ω × (I·ω))
```

### Cross Product in Components
```
a × b = [ay·bz - az·by]
        [az·bx - ax·bz]
        [ax·by - ay·bx]
```

## Common Pitfalls and Notes

### 1. Quaternion Normalization
- Quaternions should maintain unit norm
- Numerical drift can occur during integration
- Periodically re-normalize: `q_norm = q / ||q||`
- Or add algebraic constraint: `q[1]² + q[2]² + q[3]² + q[4]² = 1`

### 2. Gimbal Lock in Euler Angles
- Occurs when pitch = ±90°
- Quaternions avoid this issue
- When converting to Euler, handle singularity:
  ```
  if |sin(pitch)| ≥ 1:
      pitch = sign(sin(pitch)) * π/2
  ```

### 3. Velocity in Rotating Frames
- ECEF velocity ≠ rotated ECI velocity
- Must account for: `v_ECEF = R * v_ECI - ω × r_ECEF`
- The -ω × r term is the Earth rotation contribution

### 4. Dynamic Pressure Definition
```
q = 0.5 * ρ * V²

where:
  ρ = air density [kg/m³]
  V = velocity magnitude in body frame [m/s]
```
**Important**: Use velocity in body frame for aerodynamics!

### 5. Angle of Attack and Sideslip
```
α = atan2(v_body[3], v_body[1])  (pitch plane)
β = asin(v_body[2] / |v_body|)   (yaw plane)
```

Body frame convention (X-forward, Y-right, Z-down) affects signs!

### 6. Sign Conventions for Moments
- **Roll moment (Mx)**: About X-axis (longitudinal)
  - Positive → right wing down
- **Pitch moment (My)**: About Y-axis (lateral)
  - Positive → nose up
- **Yaw moment (Mz)**: About Z-axis (vertical)
  - Positive → nose right

### 7. WGS84 vs Spherical Earth
- WGS84 is an ellipsoid (oblate spheroid)
- Equatorial radius: a = 6378137 m
- Polar radius: b ≈ 6356752 m
- Difference at poles: ~21 km
- Use WGS84 for accurate altitude over Earth's surface

## Validation Checks

### Energy Conservation (Vacuum Flight)
```
E_specific = V²/2 - μ/r = constant

where:
  V = velocity magnitude in ECI
  r = position magnitude in ECI
  μ = 3.986004418e14 m³/s²
```

### Angular Momentum Conservation (No External Moments)
```
H_ECI = I_body * ω_body (transformed to ECI) = constant

H_ECI = R_Body_to_ECI * (I_body * ω_body)
```

### Quaternion Norm
```
||q|| = √(w² + x² + y² + z²) = 1 ± tolerance
```

### Rotation Matrix Properties
```
R^T * R = I (orthogonality)
det(R) = 1 (proper rotation)
```

## Reference Implementation Snippets

### Rotating a Vector with Quaternion (Alternative Method)
```python
def rotate_vector_by_quaternion(v, q):
    """Rotate vector v by quaternion q"""
    # q * [0, v] * q^*
    q_v = [0, v[0], v[1], v[2]]
    q_conj = [q[0], -q[1], -q[2], -q[3]]
    temp = quaternion_multiply(q, q_v)
    result = quaternion_multiply(temp, q_conj)
    return [result[1], result[2], result[3]]
```

### Computing Orbital Elements
```python
def compute_orbital_elements(r_ECI, v_ECI):
    """Compute classical orbital elements from state vectors"""
    r = np.linalg.norm(r_ECI)
    v = np.linalg.norm(v_ECI)
    
    # Specific angular momentum
    h_vec = np.cross(r_ECI, v_ECI)
    h = np.linalg.norm(h_vec)
    
    # Inclination
    i = np.arccos(h_vec[2] / h)
    
    # Eccentricity vector
    e_vec = np.cross(v_ECI, h_vec)/mu - r_ECI/r
    e = np.linalg.norm(e_vec)
    
    # Semi-major axis
    energy = v**2/2 - mu/r
    a = -mu / (2*energy)
    
    return a, e, i
```

## Further Reading

1. **Quaternions**: "Quaternions and Rotation Sequences" by J. B. Kuipers
2. **Orbital Mechanics**: "Fundamentals of Astrodynamics" by Bate, Mueller, White
3. **Spacecraft Attitude**: "Spacecraft Attitude Determination and Control" by Wertz
4. **WGS84**: NIMA Technical Report TR8350.2
5. **Rocket Dynamics**: "Atmospheric and Space Flight Dynamics" by Tewari

---
*This reference guide accompanies the Rocket 6-DOF Modelica model*
